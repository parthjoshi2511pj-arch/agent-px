package com.agentpx.assistant.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class AgentPxNotificationListener : NotificationListenerService() {

    companion object {
        var activeNotificationsList: List<NotificationSummary> = emptyList()
            private set
    }

    data class NotificationSummary(
        val appName: String,
        val title: String,
        val text: String,
        val postTime: Long
    )

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        refreshActiveNotifications()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        refreshActiveNotifications()
    }

    private fun refreshActiveNotifications() {
        try {
            val list = mutableListOf<NotificationSummary>()
            for (sbn in activeNotifications) {
                val extras = sbn.notification.extras
                val title = extras.getCharSequence("android.title")?.toString() ?: ""
                val text = extras.getCharSequence("android.text")?.toString() ?: ""
                if (title.isNotBlank() || text.isNotBlank()) {
                    list.add(
                        NotificationSummary(
                            appName = sbn.packageName,
                            title = title,
                            text = text,
                            postTime = sbn.postTime
                        )
                    )
                }
            }
            activeNotificationsList = list
        } catch (_: Exception) {}
    }
}
