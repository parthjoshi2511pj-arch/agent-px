package com.agentpx.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agentpx.assistant.brain.GeminiAgentBrain
import com.agentpx.assistant.device.DeviceActionHandler
import com.agentpx.assistant.permissions.PermissionManager
import com.agentpx.assistant.safety.CommandSafetyGate
import com.agentpx.assistant.safety.SafetyCheckResult
import com.agentpx.assistant.ui.AgentPxTheme
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var deviceHandler: DeviceActionHandler
    private lateinit var brain: GeminiAgentBrain
    private lateinit var safetyGate: CommandSafetyGate
    private lateinit var permManager: PermissionManager

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Permissions updated
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)
        deviceHandler = DeviceActionHandler(this)
        brain = GeminiAgentBrain()
        safetyGate = CommandSafetyGate(this)
        permManager = PermissionManager(this)

        initSpeechRecognizer()

        setContent {
            AgentPxTheme {
                MainAgentPxScreen(
                    deviceHandler = deviceHandler,
                    permManager = permManager,
                    onStartVoice = { startListening() },
                    onStopVoice = { stopListening() },
                    onExecuteText = { text -> executeUserCommand(text) }
                )
            }
        }
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {}
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        matches?.firstOrNull()?.let { command ->
                            executeUserCommand(command)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }
        speechRecognizer?.startListening(intent)
    }

    private fun stopListening() {
        speechRecognizer?.stopListening()
        tts.stop()
    }

    private fun executeUserCommand(command: String) {
        // Run classification, safety gate, device execution, then speak response
        val action = brain.classifyCommand(command)
        val safety = safetyGate.evaluate(action)

        if (!safety.isAllowed) {
            speakOut(safety.rejectionReason)
            return
        }

        val result = deviceHandler.executeAction(action)
        speakOut(result.spokenResponse)
    }

    private fun speakOut(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AgentPxSpeech")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.ENGLISH
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}

@Composable
fun MainAgentPxScreen(
    deviceHandler: DeviceActionHandler,
    permManager: PermissionManager,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onExecuteText: (String) -> Unit
) {
    var commandText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF030712)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AGENT PX",
                    color = Color(0xFF00F0FF),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Badge(containerColor = Color(0xFF00F0FF).copy(alpha = 0.2f)) {
                    Text("ONLINE", color = Color(0xFF00F0FF))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Holographic JARVIS Orb
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFF00F0FF).copy(alpha = 0.35f), Color.Transparent)
                        )
                    )
                    .border(2.dp, Color(0xFF00F0FF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = "Voice Matrix",
                    tint = Color(0xFF00F0FF),
                    modifier = Modifier.size(64.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Controls
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                IconButton(
                    onClick = {
                        isListening = !isListening
                        if (isListening) onStartVoice() else onStopVoice()
                    },
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0xFF00F0FF).copy(alpha = 0.2f), CircleShape)
                        .border(1.dp, Color(0xFF00F0FF), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Microphone",
                        tint = Color(0xFF00F0FF)
                    )
                }

                IconButton(
                    onClick = { onStopVoice() },
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color.Red.copy(alpha = 0.2f), CircleShape)
                        .border(1.dp, Color.Red, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop",
                        tint = Color.Red
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Text Command Input
            OutlinedTextField(
                value = commandText,
                onValueChange = { commandText = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Enter command or tap microphone...", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00F0FF),
                    unfocusedBorderColor = Color.DarkGray,
                    focusedTextColor = Color.White
                ),
                trailingIcon = {
                    IconButton(onClick = {
                        if (commandText.isNotBlank()) {
                            onExecuteText(commandText)
                            commandText = ""
                        }
                    }) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF00F0FF))
                    }
                }
            )
        }
    }
}
