package com.agentpx.assistant.device

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager
import com.agentpx.assistant.brain.ActionPlan

data class ExecutionResult(
    val success: Boolean,
    val spokenResponse: String,
    val logNote: String
)

class DeviceActionHandler(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var isTorchOn = false

    fun executeAction(action: ActionPlan): ExecutionResult {
        return when (action.tool) {
            "get_battery_status" -> getBatteryStatus()
            "control_flashlight" -> toggleTorch(action.parameters["state"] == "on")
            "control_volume" -> adjustVolume(action.parameters["action"] as? String ?: "up")
            "open_application" -> launchApp(action.parameters["packageName"] as? String, action.parameters["appName"] as? String)
            "make_phone_call" -> initiatePhoneCall(action.parameters["phone_number"] as? String ?: "")
            "send_sms" -> sendDirectSms(action.parameters["recipient"] as? String ?: "", action.parameters["message"] as? String ?: "")
            "set_alarm" -> setAlarm(action.parameters["time"] as? String ?: "06:00", action.parameters["label"] as? String ?: "AGENT PX Alarm")
            "search_web" -> searchWeb(action.parameters["query"] as? String ?: "")
            "device_setting_page" -> openSettings(action.parameters["page"] as? String ?: "main")
            else -> ExecutionResult(true, "Action processed.", "Handled via system intent.")
        }
    }

    fun getBatteryStatus(): ExecutionResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val isCharging = bm.isCharging
        val chargingStr = if (isCharging) "currently charging" else "discharging on battery power"
        return ExecutionResult(
            success = true,
            spokenResponse = "Battery percentage is at $level percent, $chargingStr.",
            logNote = "Battery level: $level%, charging: $isCharging"
        )
    }

    fun toggleTorch(enable: Boolean): ExecutionResult {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return ExecutionResult(false, "No flashlight available on this device.", "Camera ID null")
            cameraManager.setTorchMode(cameraId, enable)
            isTorchOn = enable
            ExecutionResult(
                success = true,
                spokenResponse = if (enable) "Flashlight activated." else "Flashlight turned off.",
                logNote = "Torch set to $enable"
            )
        } catch (e: CameraAccessException) {
            ExecutionResult(false, "Unable to access device flashlight.", e.message ?: "")
        }
    }

    fun adjustVolume(direction: String): ExecutionResult {
        val dir = if (direction == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return ExecutionResult(true, "Volume adjusted $direction.", "Stream volume modified.")
    }

    fun launchApp(packageName: String?, appName: String?): ExecutionResult {
        if (packageName != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                context.startActivity(intent)
                return ExecutionResult(true, "Opening $appName.", "Launched $packageName")
            }
        }
        return ExecutionResult(false, "Application $appName is not currently installed.", "App not found")
    }

    fun initiatePhoneCall(number: String): ExecutionResult {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return ExecutionResult(true, "Calling $number.", "Dispatched ACTION_CALL intent")
    }

    fun sendDirectSms(recipient: String, message: String): ExecutionResult {
        val smsManager = SmsManager.getDefault()
        smsManager.sendTextMessage(recipient, null, message, null, null)
        return ExecutionResult(true, "SMS dispatched to $recipient.", "Sent via SmsManager")
    }

    fun setAlarm(timeStr: String, label: String): ExecutionResult {
        val parts = timeStr.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 6
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return ExecutionResult(true, "Alarm set for $timeStr.", "Scheduled alarm intent")
    }

    fun searchWeb(query: String): ExecutionResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$query")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return ExecutionResult(true, "Searching the web for $query.", "Opened browser intent")
    }

    fun openSettings(page: String): ExecutionResult {
        val intent = when (page) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }.apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        context.startActivity(intent)
        return ExecutionResult(true, "Opening Android Settings.", "Dispatched settings intent")
    }
}
