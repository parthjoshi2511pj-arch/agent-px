package com.agentpx.assistant.brain

data class ActionPlan(
    val tool: String,
    val category: String,
    val parameters: Map<String, Any>,
    val requiresConfirmation: Boolean = false
)

class GeminiAgentBrain {

    fun classifyCommand(command: String): ActionPlan {
        val lower = command.lowercase()
        return when {
            lower.contains("flashlight") || lower.contains("torch") || lower.contains("फ्लैशलाइट") -> {
                val state = if (lower.contains("off") || lower.contains("बंद")) "off" else "on"
                ActionPlan("control_flashlight", "PERMISSION_REQUIRED", mapOf("state" to state))
            }
            lower.contains("battery") || lower.contains("बैटरी") -> {
                ActionPlan("get_battery_status", "SAFE", emptyMap())
            }
            lower.contains("volume") || lower.contains("आवाज़") -> {
                val dir = if (lower.contains("down") || lower.contains("कम")) "down" else "up"
                ActionPlan("control_volume", "SAFE", mapOf("action" to dir))
            }
            lower.contains("alarm") || lower.contains("अलार्म") -> {
                ActionPlan("set_alarm", "SAFE", mapOf("time" to "06:00", "label" to "AGENT PX Alarm"))
            }
            lower.contains("youtube") -> {
                ActionPlan("open_application", "SAFE", mapOf("appName" to "YouTube", "packageName" to "com.google.android.youtube"))
            }
            lower.contains("whatsapp") -> {
                ActionPlan("open_application", "SAFE", mapOf("appName" to "WhatsApp", "packageName" to "com.whatsapp"))
            }
            lower.contains("call") || lower.contains("कॉल") -> {
                ActionPlan("make_phone_call", "CONFIRMATION_REQUIRED", mapOf("phone_number" to "1234567890"), requiresConfirmation = true)
            }
            lower.contains("sms") || lower.contains("संदेश") -> {
                ActionPlan("send_sms", "CONFIRMATION_REQUIRED", mapOf("recipient" to "Contact", "message" to "Hello"), requiresConfirmation = true)
            }
            else -> ActionPlan("search_web", "SAFE", mapOf("query" to command))
        }
    }
}
