package com.agentpx.assistant.safety

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.agentpx.assistant.brain.ActionPlan

data class SafetyCheckResult(
    val isAllowed: Boolean,
    val needsConfirmation: Boolean,
    val rejectionReason: String = ""
)

class CommandSafetyGate(private val context: Context) {

    fun evaluate(action: ActionPlan): SafetyCheckResult {
        // Enforce confirmation on consequential actions
        if (action.requiresConfirmation || action.tool == "make_phone_call" || action.tool == "send_sms") {
            return SafetyCheckResult(
                isAllowed = true,
                needsConfirmation = true,
                rejectionReason = "Confirmation required before consequential action."
            )
        }

        // Check required runtime permissions
        val requiredPermission = when (action.tool) {
            "control_flashlight" -> android.Manifest.permission.CAMERA
            "make_phone_call" -> android.Manifest.permission.CALL_PHONE
            "send_sms" -> android.Manifest.permission.SEND_SMS
            else -> null
        }

        if (requiredPermission != null) {
            val granted = ContextCompat.checkSelfPermission(context, requiredPermission) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                return SafetyCheckResult(
                    isAllowed = false,
                    needsConfirmation = false,
                    rejectionReason = "Required Android permission $requiredPermission has not been authorized."
                )
            }
        }

        return SafetyCheckResult(isAllowed = true, needsConfirmation = false)
    }
}
