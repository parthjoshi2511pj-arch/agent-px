# Agent PX ProGuard rules (minification is disabled for this build).
